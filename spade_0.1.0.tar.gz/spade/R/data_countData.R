#' Simulated RNA-seq read counts data.
#'
#' A dataset containing the prices and other attributes of almost 54,000
#' diamonds.
#'
#' @format A data frame with 10 rows and 90 samples. Each row represent a gene, each sample represent a experiment condition.


"countData"
