
shrink_sigma <- function(sigma,shrink=TRUE){

    if(shrink){

        rid <- which(is.na(sigma))
        N0 <- length(sigma)
        if(length(rid)>0) sigma <- sigma[-rid]

        G <- length(sigma)
        d <- 58 # N - rank(X)

        ## estimate d0 and s02
        sg2 <- sigma^2
        zg <- log(sg2)
        eg <- zg - digamma(d/2) + log(d/2)
        ebar <- mean(eg)
        xx <- mean((eg-ebar)^2*G/(G-1)-trigamma(d/2))

        f <- function(d0) abs(trigamma(d0/2) - xx)

        d0 <- stats::optimize(f,interval=c(0,G*2))$minimum
        s02 <- exp(ebar+digamma(d0/2)-log(d0/2))
        sigma.shrink <- sqrt((d0*s02+d*sg2)/(d0+d))

        if(length(rid)>0){
            new <- rep(NA,N0)
            new[-rid] <- sigma.shrink
            sigma.shrink <- new
        }

    } else sigma.shrink <- sigma

    return(sigma.shrink)

}

