
mkpdR <- function(rho){
    R <- matrix(1,6,6)
    R[lower.tri(R)] <- rho
    R <- (R * lower.tri(R)) + t(R * lower.tri(R))
    diag(R) <- 1
    return(R)
}


simudat_weight <- function(fix,weight,lib.size=NULL,sig,rhos,X,path_name){

    names <- rownames(fix)
    rid <- which(is.na(sig))
    if(length(rid)>0){
        fix <- fix[-rid,]
        weight <- weight[-rid,]
        sig <- sig[-rid]
        rhos <- rhos[-rid,]
    }

    ## fixed
    fixed <- fix%*%t(X)
    N <- nrow(fixed)
    nc <- ncol(fixed)

    ## random
    ranf <- matrix(NA,N,nc)
    seed <- sample(1:80000000,1)
    set.seed(seed)

    logcpm <- matrix(0,N,nc)
    for(i in 1:N){
        r <- mkpdR(rhos[i,])
        if(!matrixcalc::is.positive.definite(r)) r <- diag(6)
        R <- sig[i]^2*Matrix::bdiag(replicate(15,r,FALSE))
        w <- diag(nc)
        diag(w) <- 1/sqrt(weight[i,])
        ranf[i,] <- MASS::mvrnorm(1,rep(0,nc),w%*%R%*%w)
    }
    logcpm <- fixed+ranf


    count <- 1e-06 * t(t(2^logcpm) * (lib.size + 1)) - 0.5
    count[count<0] <- 0
    new.lib.size <- apply(count,2,stats::quantile,0.75)
    y <- limma::voom(count,X,new.lib.size)
    estw <- y$weights
    newlogcpm <- y$E


    if(length(rid)>0){
        M <- length(rid)+N
        tmp.newlogcpm <- matrix(NA,M,nc)
        tmp.newlogcpm[-rid,] <- newlogcpm
        newlogcpm <- tmp.newlogcpm
        tmp.estw <- matrix(NA,M,nc)
        tmp.estw[-rid,] <- estw
        estw <- tmp.estw
    }

    rownames(newlogcpm) <- names
    out <- list(logcpm=newlogcpm,weight=estw,lib.size=new.lib.size,seed=seed)
    return(out)
}



