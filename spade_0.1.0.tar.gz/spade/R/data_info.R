#' Infomation dataframe
#'
#' A dataframe containing the experimental condition in countData.

"info"
