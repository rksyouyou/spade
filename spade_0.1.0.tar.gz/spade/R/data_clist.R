#' A list of contrast matrices
#'
#' A dataset containing two contrast matrices.
#'
#' @format A list with two contrast matrices.
#' The columns of each constrast matrix is corresponding to the columns of design matrix.

"clist"
