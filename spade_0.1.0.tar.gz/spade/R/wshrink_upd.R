lfit <- function(x,avg) stats::lowess(avg,x)$y[rank(avg)]
ztrans <- function(x) log((1+x)/(1-x))/2
bztrans <- function(x) (exp(2*x)-1)/(exp(2*x)+1)
checkpd <- function(rho){
    R <- matrix(1,6,6)
    R[lower.tri(R)] <- rho
    R <- (R * lower.tri(R)) + t(R * lower.tri(R))
    diag(R) <- 1
    matrixcalc::is.positive.definite(R)
}

shrink_cor <- function(estP1,estP2,avg1,avg2,bound=1){

    rid <- which(is.na(avg1)|is.na(avg2))
    N0 <- length(avg1)
    if(length(rid)>0){
        estP1 <- estP1[-rid,]
        estP2 <- estP2[-rid,]
        avg1 <- avg1[-rid]
        avg2 <- avg2[-rid]
    }

    zestP1 <- ztrans(estP1)
    zestP2 <- ztrans(estP2)
    zfitP1 <- apply(zestP1,2,lfit,avg1)
    zfitP2 <- apply(zestP2,2,lfit,avg2)
    e2mat1 <- (zestP1-zfitP1)^2
    e2mat2 <- (zestP2-zfitP2)^2

    intM1 <- intM2 <- NULL
    for(i in 1:15){
        fit1 <- stats::lowess(avg1,e2mat1[,i])
        fit2 <- stats::lowess(avg2,e2mat2[,i])
        ## lowess interpolation
        intM1 <- cbind(intM1,stats::approx(x=fit1$x, y = fit1$y, xout = avg1)$y)
        tavg <- avg1
        tavg[avg1>max(fit2$x)] <- max(fit2$x)
        tavg[avg1<min(fit2$x)] <- min(fit2$x)
        intM2 <- cbind(intM2,stats::approx(x=fit2$x, y = fit2$y, xout = tavg)$y)
    }

    ## shrikage estimation
    w <- intM2/intM1
    w[w>bound] <- bound
    wsh <- bztrans(w*zfitP1 + (1-w)*zestP1)

    ## check pd
    N <- nrow(wsh)
    flag <- rep(NA,N)
    for(i in 1:N) flag[i] <- checkpd(wsh[i,])
    wsh[!flag,] <- zfitP1[!flag,]

    if(length(rid)>0) {
        new <- matrix(NA,N0,ncol(wsh))
        new[-rid,] <- wsh
        wsh <- new
    }

    return(wsh)
}

upd_sig_fixed <- function(X,rhos,weight,y){

    N <- nrow(y)
    fixed <- matrix(NA,N,ncol(X))
    sig <- rep(NA,N)
    df <- ncol(y)-qr(X)$rank

    for(i in 1:N){
        w <- diag(nrow(X))
        diag(w) <- 1/sqrt(weight[i,])
        tmpy <- matrix(y[i,],ncol=1)
        V <- w%*%Matrix::bdiag(replicate(15,mkpdR(rhos[i,]),FALSE))%*%w
        inV <- solve(V)
        XV <- t(X)%*%inV
        fixed[i,] <- as.vector(solve(XV%*%X)%*%(XV%*%tmpy))
        P <- inV - t(XV)%*%solve(XV%*%X)%*%XV
        sig[i] <- (t(tmpy)%*%P%*%tmpy)/df
    }

    return(list(fixed=fixed,sig=sqrt(sig)))
}


wshrink_upd <- function(res0,res1,X,logcpm,weight){
    ## correlation matrix adjustment
    bound <- 1
    estP0 <- res0$estP
    estP1 <- res1$estP
    avg0 <- rowMeans(t(X%*%t(res0$fixed)))
    avg1 <- rowMeans(t(X%*%t(res1$fixed)))
    rhos.upd <- shrink_cor(estP0,estP1,avg0,avg1,bound)
    upd <- upd_sig_fixed(X,rhos.upd,weight,logcpm)
    fixed.upd <- upd$fixed
    sig.upd <- upd$sig
    sig.upd <- shrink_sigma(sig.upd)
    rownames(fixed.upd) <- rownames(res0$fixed)
    rownames(rhos.upd) <- rownames(res0$fixed)

    n1 <- sum(is.na(res0$sig))
    n2 <- sum(is.na(res1$sig))
    if(n1==0) cat('All genes converge sucessfully in the initial estiamtion.\n')
    if(n1==1) cat('One gene fails to converge in the initial estiamtion.\n')
    if(n1>1) cat(n1, ' genes fail to converge in the initial estiamtion.\n')
    if(n2==0) cat('All genes converge sucessfully in the intermediate estiamtion.\n')
    if(n2==1) cat('One gene fails to converge in the intermediate estiamtion.\n')
    if(n2>1) cat(n2, 'genes fail to converge in the intermediate estiamtion.\n')
    if(n2-n1==1) cat('The initial estimation is used used for one gene in the final result.\n')
    if(n2-n1>1) cat('The initial estimation is used used for',n2-n1,'genes in the final result.\n')


    if(n2>n1){
        naid <- which(is.na(res1$sig)&!is.na(res0$sig))
        fixed.upd[naid,] <- res0$fixed[naid,]
        sig.upd[naid] <- res0$sig[naid]
        rhos.upd[naid,] <- res0$estP[naid,]
    }
    out <- list(fixed=fixed.upd,sig=sig.upd,estP=rhos.upd)
    return(out)
}


