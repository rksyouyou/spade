
priorM <- function(avgexpr,estP){
    nc <- ncol(estP)
    priorP <- matrix(NA,length(avgexpr),nc)
    ind <- which(is.na(estP[,1]))
    for(i in 1:nc){
        if(length(ind)>0) lo <- stats::lowess(avgexpr[-ind],estP[-ind,i]) else lo <- stats::lowess(avgexpr,estP[,i])
        priorP[,i] <- stats::approx(x=lo$x,y=lo$y,xout=avgexpr)$y
    }
    return(priorP)
}
