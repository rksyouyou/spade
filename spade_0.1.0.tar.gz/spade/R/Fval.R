
Fval <- function(cmat,X,fix1,fix2=NULL,weight=NULL,rhos,shrinksig,eps=1e-03){

    rankc <- qr(cmat)$rank
    if(is.null(fix2)) cfixed <- t(cmat%*%t(fix1)) else cfixed <- t(cmat%*%t(fix1-fix2))

   N <- nrow(fix1)
    nc <- nrow(X)

    ff <- function(i){
        if(is.na(shrinksig[i])) return(NA)
        else {
            r <- (1-eps)*mkpdR(rhos[i,]) + eps*diag(6)
            R <- Matrix::bdiag(replicate(15,r,FALSE))
            w <- diag(nc)
            if(!is.null(weight))  diag(w) <- 1/sqrt(weight[i,])
            tmpV <- w%*%R%*%w
            fval <- tryCatch(t(cfixed[i,])%*%solve(cmat%*%solve(t(X)%*%solve(tmpV)%*%X)%*%t(cmat))%*%cfixed[i,]/rankc/(shrinksig[i]^2), error = function(e)NULL)
            if(is.null(fval)) fval <- NA
            return(as.numeric(fval))
        }
   }

    val <- unlist(parallel::mclapply(1:N,ff))
    return(val)
}





