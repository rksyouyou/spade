


glsfit_unstr_ww_onesample <- function(i,logcpm,Xd,cgroup,weight){
    y <- logcpm[i,]
    w <- weight[i,]
    res <- tryCatch(nlme::gls(y~0+Xd,correlation=nlme::corSymm(form=~1|cgroup),weights=~I(1/w)), error = function(e)NULL)
    if(is.null(res)) res <- tryCatch(nlme::gls(y~0+Xd,correlation=nlme::corSymm(form=~1|cgroup),weights=~1/w,control=list(opt='optim')), error = function(e)NULL)
    timecor <- stats::coef(res$modelStruct$corStruct,uncons=FALSE,allCoef=TRUE)
    fixed <- stats::coef(res)
    sig <- res$sigma
    return(list(timecor,fixed,sig))
}

glsfit_unstr_weight <- function(logcpm, X, cgroup, weight){
    smyth <- TRUE
    ## clean gls output
    nR <- nrow(logcpm)
    res <- pbmcapply::pbmclapply(1:nR,glsfit_unstr_ww_onesample,logcpm = logcpm, Xd = X, cgroup = cgroup, weight = weight)
    fixed <- matrix(NA,nR,ncol(X))
    T <- nrow(X)/length(unique(cgroup))
    estP <- matrix(NA,nR,T*(T-1)/2)
    sig <- rep(NA,nR)
    for(i in 1:nR){
        if(!is.null(res[[i]][[1]])){
            estP[i,] <- res[[i]][[1]]
            fixed[i,] <- res[[i]][[2]]
            sig[i] <- res[[i]][[3]]
        }
    }
    rownames(estP) <- rownames(logcpm)
    rownames(fixed) <- rownames(logcpm)
    if(smyth) sig <- shrink_sigma(sig)
    out <- list(fixed=fixed,sig=sig,estP=estP)
    return(out)
}


