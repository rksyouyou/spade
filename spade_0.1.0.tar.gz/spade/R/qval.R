# Q-value Using Histogram-based Method
# This function computes q-values using the approach of Nettleton et al.
#(2006) JABES 11, 337-356.

estimate.m0 = function(p, B = 20) {
    
    m <- length(p)
    m0 <- m
    bin <- c(-0.1, (1:B)/B)
    bin.counts = rep(0, B)
    for (i in 1:B) bin.counts[i] = sum((p > bin[i]) & (p <= bin[i + 1]))

    tail.means <- rev(cumsum(rev(bin.counts))/(1:B))
    temp <- bin.counts - tail.means
    index <- min((1:B)[temp <= 0])
    m0 <- B * tail.means[index]
    return(m0)
}


jabes.q = function(p, B = 20) {

    rid <- which(is.na(p))
    if(length(rid)>0) p <- p[-rid]

    m = length(p)
    m0 = estimate.m0(p, B)
    k = 1:m
    ord = order(p)
    p[ord] = (p[ord] * m0)/(1:m)
    qval = p
    qval[ord] = rev(cummin(rev(qval[ord])))

    if(length(rid)>0) {
        tmp <- rep(NA,m+length(rid))
        tmp[rid] <- NA
        tmp[-rid] <- qval
        qval <- tmp
    }
    
    return(qval)
}
